import Image from "next/image";
import Link from "next/link";
import black from "@/assets/syx-logo-black.png";
import white from "@/assets/syx-logo-white.png";

// The SYX wordmark. Black on light pages, white on dark surfaces.
export function Logo({ tone = "black", className = "h-7 w-auto", href }: { tone?: "black" | "white"; className?: string; href?: string }) {
  const img = <Image src={tone === "white" ? white : black} alt="SYX" priority className={className} />;
  return href ? (
    <Link href={href} aria-label="SYX home" className="inline-flex">
      {img}
    </Link>
  ) : (
    img
  );
}

// Page header. With a right slot (admin): logo left, slot right. Without one
// (customer / login pages): logo centred. `dark` flips the surface.
export function Header({ dark = false, right, href }: { dark?: boolean; right?: React.ReactNode; href?: string }) {
  return (
    <header className={`flex h-16 items-center px-5 md:px-8 ${right ? "justify-between" : "justify-center"} ${dark ? "bg-ink text-paper" : "border-b border-line bg-paper"}`}>
      <Logo tone={dark ? "white" : "black"} href={href} className={right ? "h-7 w-auto" : "h-8 w-auto"} />
      {right}
    </header>
  );
}
