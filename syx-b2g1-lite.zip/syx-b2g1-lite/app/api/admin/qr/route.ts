import { NextResponse } from "next/server";
import QRCode from "qrcode";
import { getSession } from "@/lib/session";
import { appUrl } from "@/lib/url";

// Print-ready QR (1200px, high error correction) for the single claim page.
export async function GET() {
  const s = await getSession();
  if (!s || s.role !== "admin") return new NextResponse("Unauthorized", { status: 401 });
  const png = await QRCode.toBuffer(`${await appUrl()}/claim`, { type: "png", width: 1200, margin: 2, errorCorrectionLevel: "H", color: { dark: "#000000", light: "#ffffff" } });
  return new NextResponse(new Uint8Array(png), {
    headers: { "Content-Type": "image/png", "Content-Disposition": `attachment; filename="syx-b2g1-qr.png"`, "Cache-Control": "private, no-store" },
  });
}
