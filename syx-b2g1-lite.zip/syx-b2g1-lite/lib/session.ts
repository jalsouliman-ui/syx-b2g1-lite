import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "./db";

// Signed-cookie sessions with node:crypto. Payload = { uid, exp }. The user row
// is re-read on every request so disabling an account takes effect immediately.

const COOKIE = "syx_session";
const TTL_MS = 12 * 60 * 60 * 1000; // 12h

export type Role = "admin";
export type SessionUser = { id: string; username: string; role: Role };

const secret = () => {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new Error("SESSION_SECRET must be set (16+ chars)");
  return s;
};

export const hmac = (data: string) => createHmac("sha256", secret()).update(data).digest("base64url");

const sign = (payload: object) => {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${hmac(body)}`;
};

const verify = (token: string): { uid: string; exp: number } | null => {
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = hmac(body);
  if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString());
    return typeof p.uid === "string" && typeof p.exp === "number" && p.exp > Date.now() ? p : null;
  } catch {
    return null;
  }
};

export async function createSession(uid: string) {
  const exp = Date.now() + TTL_MS;
  (await cookies()).set(COOKIE, sign({ uid, exp }), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(exp),
  });
}

export async function destroySession() {
  (await cookies()).delete(COOKIE);
}

export async function getSession(): Promise<SessionUser | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  const p = token ? verify(token) : null;
  if (!p) return null;
  const u = await db.user.findUnique({ where: { id: p.uid } });
  if (!u || !u.active) return null;
  return { id: u.id, username: u.username, role: u.role as Role };
}

// Server-side role gate. Redirects to the login page when unauthenticated.
export async function requireRole(role: Role): Promise<SessionUser> {
  const s = await getSession();
  if (!s || s.role !== role) redirect(`/${role}/login`);
  return s;
}
