"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { resendOtp, startClaim, verifyOtp, type ErrCode } from "./actions";
import { type ClaimErrors, validateClaim } from "@/lib/validate";

// EN + AR copy. Arabic strings render inside lang="ar" dir="rtl" containers.
const T = {
  headline: ["BUY 2\nGET 1 FREE", "اشترِ 2\nواحصل على 1 مجاناً"],
  intro: [
    "Bought two SYX? Enter your details, verify your email and get a one-time code for your free third pack.",
    "اشتريت عبوتين من SYX؟ أدخل بياناتك، وتحقق من بريدك الإلكتروني، واحصل على رمز لمرة واحدة لاستلام العبوة الثالثة مجاناً.",
  ],
  store: ["Store name", "اسم المتجر"],
  storeHint: ["Where you bought your SYX", "أين اشتريت SYX"],
  name: ["Full name", "الاسم الكامل"],
  phone: ["UAE mobile number", "رقم الهاتف الإماراتي"],
  email: ["Email", "البريد الإلكتروني"],
  emailHint: ["We'll email your verification code here.", "سنرسل رمز التحقق إلى هذا البريد."],
  receipt: ["Receipt / invoice number (optional)", "رقم الفاتورة (اختياري)"],
  submit: ["Get my code", "احصل على الرمز"],
  sending: ["Sending code…", "جارٍ الإرسال…"],
  otpTitle: ["Enter the 6-digit code", "أدخل الرمز المكوّن من 6 أرقام"],
  otpSent: ["We emailed it to", "أرسلناه بالبريد الإلكتروني إلى"],
  otpSpam: ["Not there? Check your spam folder.", "لم يصلك؟ تحقق من مجلد الرسائل غير المرغوب فيها."],
  verify: ["Verify", "تحقق"],
  verifying: ["Verifying…", "جارٍ التحقق…"],
  resend: ["Resend code", "إعادة إرسال الرمز"],
  resendIn: ["Resend in", "إعادة الإرسال خلال"],
  changeDetails: ["Change details", "تعديل البيانات"],
  doneTitle: ["Your free-item code", "رمز عبوتك المجانية"],
  doneShow: ["Show this code to the cashier to receive your FREE item.", "أظهر هذا الرمز للكاشير لاستلام عبوتك المجانية."],
  doneOnce: ["It can only be used once. Take a screenshot to keep it.", "يمكن استخدامه مرة واحدة فقط. خذ لقطة شاشة للاحتفاظ به."],
  demo: ["DEMO MODE · your OTP is", "وضع تجريبي · رمز التحقق هو"],
} as const;

const ERR: Record<ErrCode, [string, string]> = {
  RATE: ["Too many attempts. Please wait a few minutes and try again.", "محاولات كثيرة. يرجى الانتظار بضع دقائق ثم المحاولة مجدداً."],
  INVALID: ["Please check the highlighted fields.", "يرجى مراجعة الحقول المحددة."],
  CLOSED: ["The promotion isn't running right now.", "العرض غير متاح حالياً."],
  DUP_PHONE: ["This mobile number has already claimed the offer. One claim per number.", "تم استخدام هذا الرقم للمطالبة بالعرض من قبل. مطالبة واحدة لكل رقم."],
  DUP_RECEIPT: ["This receipt number has already been used.", "تم استخدام رقم الفاتورة هذا من قبل."],
  MAIL_FAIL: ["We couldn't send the email. Please check the address and try again.", "تعذّر إرسال البريد الإلكتروني. تحقق من العنوان وحاول مرة أخرى."],
  OTP_NOTFOUND: ["This verification has expired. Please start again.", "انتهت صلاحية التحقق. يرجى البدء من جديد."],
  OTP_EXPIRED: ["The code has expired. Tap resend for a new one.", "انتهت صلاحية الرمز. اضغط إعادة الإرسال للحصول على رمز جديد."],
  OTP_WRONG: ["Wrong code.", "رمز غير صحيح."],
  OTP_LOCKED: ["Too many wrong codes. Tap resend to get a new code.", "محاولات خاطئة كثيرة. اضغط إعادة الإرسال للحصول على رمز جديد."],
  RESEND_WAIT: ["Please wait before resending.", "يرجى الانتظار قبل إعادة الإرسال."],
  SERVER: ["Something went wrong. Please try again.", "حدث خطأ ما. حاول مرة أخرى."],
};

// Stacked bilingual copy: English line, Arabic line (RTL) beneath.
function Bi({ t, className = "", arClassName = "" }: { t: readonly [string, string]; className?: string; arClassName?: string }) {
  return (
    <>
      <span className={`block ${className}`}>{t[0]}</span>
      <span lang="ar" dir="rtl" className={`block ${arClassName || className}`}>{t[1]}</span>
    </>
  );
}

// Field label: English left, Arabic right. Required fields carry a red asterisk.
function FieldLabel({ htmlFor, t, required = false }: { htmlFor: string; t: readonly [string, string]; required?: boolean }) {
  const star = required && <span aria-hidden className="text-bad-deep"> *</span>;
  return (
    <label htmlFor={htmlFor} className="label flex items-baseline justify-between gap-3">
      <span>{t[0]}{star}</span>
      <span lang="ar" dir="rtl" className="text-mute">{t[1]}{star}</span>
    </label>
  );
}

// Button copy: English, Arabic beneath in a lighter weight.
function BtnText({ t }: { t: readonly [string, string] }) {
  return (
    <span className="flex flex-col items-center leading-tight">
      <span>{t[0]}</span>
      <span lang="ar" dir="rtl" className="text-sm font-medium opacity-80">{t[1]}</span>
    </span>
  );
}

function Hint({ t }: { t: readonly [string, string] }) {
  return (
    <p className="mt-1.5 text-xs text-mute">
      {t[0]} <span lang="ar" dir="rtl">{t[1]}</span>
    </p>
  );
}

export function ClaimForm() {
  const [step, setStep] = useState<"form" | "otp" | "done">("form");
  const [errors, setErrors] = useState<ClaimErrors>({});
  const [err, setErr] = useState<ErrCode | null>(null);
  const [attemptsLeft, setAttemptsLeft] = useState<number | null>(null);
  const [otpId, setOtpId] = useState("");
  const [maskedEmail, setMaskedEmail] = useState("");
  const [demoOtp, setDemoOtp] = useState<string | undefined>();
  const [otp, setOtp] = useState("");
  const [cooldown, setCooldown] = useState(60);
  const [code, setCode] = useState("");
  const [pending, start] = useTransition();
  const otpRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (step === "otp") otpRef.current?.focus();
  }, [step]);

  useEffect(() => {
    if (step !== "otp" || cooldown <= 0) return;
    const t = setInterval(() => setCooldown((c) => c - 1), 1000);
    return () => clearInterval(t);
  }, [step, cooldown]);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErr(null);
    const fd = new FormData(e.currentTarget);
    const local = validateClaim({
      name: String(fd.get("name") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      email: String(fd.get("email") ?? ""),
      storeName: String(fd.get("storeName") ?? ""),
      receiptNo: String(fd.get("receiptNo") ?? ""),
    }).errors;
    setErrors(local);
    if (Object.keys(local).length) return;

    start(async () => {
      const r = await startClaim(fd);
      if (!r.ok) {
        setErr(r.code);
        setErrors(r.errors ?? {});
        return;
      }
      setOtpId(r.otpId);
      setMaskedEmail(r.maskedEmail);
      setDemoOtp(r.demoOtp);
      setCooldown(60);
      setOtp("");
      setStep("otp");
      window.scrollTo({ top: 0 });
    });
  };

  const onVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    start(async () => {
      const r = await verifyOtp(otpId, otp);
      if (!r.ok) {
        setErr(r.code);
        setAttemptsLeft(r.attemptsLeft ?? null);
        if (r.code === "OTP_NOTFOUND") setStep("form");
        return;
      }
      setCode(r.redemptionCode);
      setStep("done");
      window.scrollTo({ top: 0 });
    });
  };

  const onResend = () => {
    setErr(null);
    start(async () => {
      const r = await resendOtp(otpId);
      if (!r.ok) {
        setErr(r.code);
        if (r.code === "RESEND_WAIT" && r.wait) setCooldown(r.wait);
        if (r.code === "OTP_NOTFOUND") setStep("form");
        return;
      }
      setDemoOtp(r.demoOtp);
      setOtp("");
      setAttemptsLeft(null);
      setCooldown(60);
    });
  };

  const errBox = err && (
    <div role="alert" className="mt-5 rounded-xl border border-bad bg-paper p-4 text-sm font-medium text-bad-deep">
      <Bi t={ERR[err]} />
      {err === "OTP_WRONG" && attemptsLeft != null && (
        <Bi t={[`${attemptsLeft} attempt${attemptsLeft === 1 ? "" : "s"} left.`, `تبقّى ${attemptsLeft} ${attemptsLeft === 1 ? "محاولة" : "محاولات"}.`]} className="mt-1" />
      )}
    </div>
  );

  if (step === "done") {
    return (
      <main className="mx-auto w-full max-w-md px-5 pt-8 pb-16">
        <h1 className="text-3xl font-bold tracking-tight">{T.doneTitle[0]}</h1>
        <p lang="ar" dir="rtl" className="text-2xl font-semibold">{T.doneTitle[1]}</p>

        <div className="mt-6 rounded-2xl bg-ink px-4 py-10 text-center text-paper" aria-live="polite">
          <p className="num text-[3.4rem] leading-none font-bold tracking-[0.18em] sm:text-7xl" data-testid="redemption-code">
            {code}
          </p>
        </div>

        <div className="mt-6 space-y-4 text-lg leading-snug">
          <Bi t={T.doneShow} className="font-semibold" />
          <Bi t={T.doneOnce} className="text-mute" arClassName="text-mute" />
        </div>
      </main>
    );
  }

  if (step === "otp") {
    return (
      <main className="mx-auto w-full max-w-md px-5 pt-8 pb-16">
        <h1 className="text-3xl font-bold tracking-tight">{T.otpTitle[0]}</h1>
        <p lang="ar" dir="rtl" className="text-2xl font-semibold">{T.otpTitle[1]}</p>
        <p className="mt-3 text-mute">
          {T.otpSent[0]} <span className="num text-ink">{maskedEmail}</span>
        </p>
        <p lang="ar" dir="rtl" className="text-mute">
          {T.otpSent[1]} <span dir="ltr" className="num text-ink">{maskedEmail}</span>
        </p>
        {!demoOtp && <Hint t={T.otpSpam} />}

        {demoOtp && (
          <div className="mt-6 rounded-2xl border-2 border-dashed border-ink p-4 text-center">
            <p className="text-xs font-semibold tracking-wide uppercase">{T.demo[0]}</p>
            <p className="num my-1 text-4xl font-bold tracking-[0.3em]">{demoOtp}</p>
            <p lang="ar" dir="rtl" className="text-xs font-semibold">{T.demo[1]}</p>
          </div>
        )}

        <form onSubmit={onVerify} className="mt-6">
          <FieldLabel htmlFor="otp" t={["OTP", "رمز التحقق"]} />
          <input
            id="otp"
            name="otp"
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="[0-9]*"
            maxLength={6}
            required
            ref={otpRef}
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
            className="input num text-center text-3xl tracking-[0.5em]"
          />
          {errBox}
          <button type="submit" disabled={pending || otp.length !== 6} className="btn mt-5">
            <BtnText t={pending ? T.verifying : T.verify} />
          </button>
        </form>

        <div className="mt-6 flex items-center justify-between text-sm">
          <button type="button" onClick={onResend} disabled={pending || cooldown > 0} className="btn-link">
            {cooldown > 0 ? `${T.resendIn[0]} ${cooldown}s` : T.resend[0]}
          </button>
          <button type="button" onClick={() => { setStep("form"); setErr(null); }} className="btn-link text-mute">
            {T.changeDetails[0]}
          </button>
        </div>
      </main>
    );
  }

  const field = (key: keyof ClaimErrors) => `input${errors[key] ? " input-err" : ""}`;

  return (
    <main className="mx-auto w-full max-w-md px-5 pt-8 pb-16">
      <h1 className="text-[2.9rem] leading-[0.92] font-bold tracking-tight whitespace-pre-line sm:text-6xl">{T.headline[0]}</h1>
      <p lang="ar" dir="rtl" className="mt-4 text-3xl leading-tight font-bold whitespace-pre-line">{T.headline[1]}</p>
      <div className="mt-5 space-y-2 text-base leading-snug text-mute">
        <Bi t={T.intro} />
      </div>

      <form onSubmit={onSubmit} noValidate className="mt-8 space-y-5">
        <div>
          <FieldLabel required htmlFor="storeName" t={T.store} />
          <input id="storeName" name="storeName" autoComplete="off" placeholder="e.g. Marina Mall, Dubai" required className={field("storeName")} aria-invalid={!!errors.storeName} />
          {errors.storeName ? <p className="err">{errors.storeName}</p> : <Hint t={T.storeHint} />}
        </div>
        <div>
          <FieldLabel required htmlFor="name" t={T.name} />
          <input id="name" name="name" autoComplete="name" required className={field("name")} aria-invalid={!!errors.name} />
          {errors.name && <p className="err">{errors.name}</p>}
        </div>
        <div>
          <FieldLabel required htmlFor="phone" t={T.phone} />
          <input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="05X XXX XXXX" required className={`${field("phone")} num`} aria-invalid={!!errors.phone} />
          {errors.phone && <p className="err">{errors.phone}</p>}
        </div>
        <div>
          <FieldLabel required htmlFor="email" t={T.email} />
          <input id="email" name="email" type="email" inputMode="email" autoComplete="email" required className={field("email")} aria-invalid={!!errors.email} />
          {errors.email ? <p className="err">{errors.email}</p> : <Hint t={T.emailHint} />}
        </div>
        <div>
          <FieldLabel htmlFor="receiptNo" t={T.receipt} />
          <input id="receiptNo" name="receiptNo" autoComplete="off" className={`${field("receiptNo")} num uppercase`} aria-invalid={!!errors.receiptNo} />
          {errors.receiptNo && <p className="err">{errors.receiptNo}</p>}
        </div>

        {errBox}

        <button type="submit" disabled={pending} className="btn">
          <BtnText t={pending ? T.sending : T.submit} />
        </button>
        <p className="text-center text-xs text-mute"><span className="text-bad-deep">*</span> required · إلزامي · One claim per mobile number · مطالبة واحدة لكل رقم هاتف</p>
      </form>
    </main>
  );
}
