import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { claimInclude, claimWhere } from "@/lib/claims-query";
import { fmtDateTime } from "@/lib/format";
import { getSession } from "@/lib/session";

const cell = (v: unknown) => {
  const s = v == null ? "" : String(v);
  // Neutralise spreadsheet formula injection, then quote. Plain "+971..." phone
  // numbers are left intact (a sign followed only by digits cannot be a formula).
  const formulaLike = /^[=@\t\r]/.test(s) || (/^[+-]/.test(s) && !/^[+-]\d+$/.test(s));
  const safe = formulaLike ? `'${s}` : s;
  return `"${safe.replace(/"/g, '""')}"`;
};

export async function GET(req: Request) {
  const s = await getSession();
  if (!s || s.role !== "admin") return new NextResponse("Unauthorized", { status: 401 });

  const sp = Object.fromEntries(new URL(req.url).searchParams);
  const claims = await db.claim.findMany({ where: claimWhere(sp), include: claimInclude, orderBy: { createdAt: "asc" } });

  const head = ["claim_id", "name", "phone", "email", "store", "receipt_no", "claimed_at_uae", "redemption_code", "redeemed", "redeemed_at_uae", "redeemed_by", "claim_ip"];
  const rows = claims.map((c) => [
    c.id, c.name, c.phone, c.email, c.storeName, c.receiptNo, fmtDateTime(c.createdAt), c.code,
    c.redeemedAt ? "yes" : "no", fmtDateTime(c.redeemedAt), c.redeemedBy?.username ?? "", c.ip,
  ]);
  const csv = "﻿" + [head, ...rows].map((r) => r.map(cell).join(",")).join("\r\n");
  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="syx-b2g1-claims-${stamp}.csv"`,
      "Cache-Control": "private, no-store",
    },
  });
}
