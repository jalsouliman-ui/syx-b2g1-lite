import type { Metadata } from "next";
import { Flash } from "@/components/Flash";
import { getSettings, promoOpen } from "@/lib/settings";
import { DEMO_MODE } from "@/lib/mail";
import { appUrl } from "@/lib/url";
import { updateSettings } from "../../actions";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  const sp = await searchParams;
  const [s, base] = await Promise.all([getSettings(), appUrl()]);
  const open = promoOpen(s);

  return (
    <>
      <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
      <Flash {...sp} />

      <section className="card mt-6 max-w-xl p-6">
        <h2 className="font-semibold">Claim page &amp; QR</h2>
        <p className="mt-1 text-sm text-mute">
          One link for every store: <a href={`${base}/claim`} className="num underline underline-offset-4" target="_blank" rel="noreferrer">{base}/claim</a>. Print this QR on the shelf wobblers.
        </p>
        <a href="/api/admin/qr" download="syx-b2g1-qr.png" className="btn-sm mt-4">Download QR (PNG, print size)</a>
      </section>

      <form action={updateSettings} className="card mt-6 max-w-xl space-y-6 p-6">
        <fieldset>
          <legend className="label">Promotion window (UAE time, inclusive)</legend>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="promoStart" className="mb-1 block text-xs text-mute">Start</label>
              <input id="promoStart" name="promoStart" type="date" defaultValue={s.promoStart} className="input" />
            </div>
            <div>
              <label htmlFor="promoEnd" className="mb-1 block text-xs text-mute">End</label>
              <input id="promoEnd" name="promoEnd" type="date" defaultValue={s.promoEnd} className="input" />
            </div>
          </div>
          <p className="mt-1.5 text-sm text-mute">Leave both empty to keep claims open. Outside the window customers see &ldquo;The promotion isn&apos;t running right now.&rdquo;</p>
          <p className="mt-2 text-sm font-medium">
            Right now: {open ? <span className="pill-ok">CLAIMS OPEN</span> : <span className="pill-bad">CLAIMS CLOSED</span>}
          </p>
        </fieldset>
        <button type="submit" className="btn-sm">Save settings</button>
      </form>

      <section className="card mt-6 max-w-xl p-6">
        <h2 className="font-semibold">OTP delivery (email)</h2>
        <p className="mt-1 text-sm text-mute">
          {DEMO_MODE
            ? "DEMO MODE: SMTP is not configured, so OTPs are shown on screen instead of emailed. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS and MAIL_FROM, then restart."
            : `SMTP configured (${process.env.SMTP_HOST}). Verification codes are emailed from ${process.env.MAIL_FROM}.`}
        </p>
      </section>
    </>
  );
}
