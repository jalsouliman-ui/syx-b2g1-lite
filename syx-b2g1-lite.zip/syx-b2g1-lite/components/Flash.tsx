// One-line result banner driven by ?ok= / ?err= after a server action redirect.
export function Flash({ ok, err }: { ok?: string; err?: string }) {
  if (!ok && !err) return null;
  return (
    <p role="status" className={`mt-4 rounded-xl border px-4 py-3 text-sm font-medium ${err ? "border-bad text-bad-deep" : "border-ok text-ok-deep"}`}>
      {err ?? ok}
    </p>
  );
}
