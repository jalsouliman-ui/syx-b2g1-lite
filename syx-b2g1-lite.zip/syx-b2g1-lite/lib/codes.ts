import { randomInt } from "node:crypto";
import { REDEMPTION_ALPHABET } from "./validate";

// CSPRNG-backed generators (server only — node:crypto).
export const newOtp = () => String(randomInt(0, 1_000_000)).padStart(6, "0");
export const newRedemptionCode = () =>
  Array.from({ length: 6 }, () => REDEMPTION_ALPHABET[randomInt(REDEMPTION_ALPHABET.length)]).join("");
