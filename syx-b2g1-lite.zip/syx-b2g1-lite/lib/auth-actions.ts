"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { db } from "./db";
import { clientIp, limited } from "./ratelimit";
import { createSession, destroySession, type Role } from "./session";

export type LoginState = { error?: string };

export async function login(role: Role, _prev: LoginState, form: FormData): Promise<LoginState> {
  const ip = await clientIp();
  if (limited(`login:${ip}`, 20, 15 * 60_000)) return { error: "Too many attempts. Try again in a few minutes." };

  const username = String(form.get("username") ?? "").trim().toLowerCase();
  const password = String(form.get("password") ?? "");
  const u = await db.user.findUnique({ where: { username } });
  // Constant-ish time: always run a compare so missing users don't return faster.
  const ok = await bcrypt.compare(password, u?.passwordHash ?? "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinval");
  if (!u || !ok || !u.active || u.role !== role) return { error: "Wrong username or password." };

  await createSession(u.id);
  redirect(`/${role}`);
}

export async function logout(role: Role) {
  await destroySession();
  redirect(`/${role}/login`);
}
