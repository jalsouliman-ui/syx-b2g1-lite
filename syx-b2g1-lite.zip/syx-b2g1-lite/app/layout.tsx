import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { IBM_Plex_Sans_Arabic } from "next/font/google";
import "./globals.css";

// Arabic companion to Geist: fetched once at build time and self-hosted by Next.
const arabic = IBM_Plex_Sans_Arabic({ subsets: ["arabic"], weight: ["400", "500", "600", "700"], variable: "--font-plex-arabic", display: "swap" });

export const metadata: Metadata = {
  title: { default: "SYX — Buy 2 Get 1 Free", template: "%s · SYX" },
  description: "SYX Buy 2 Get 1 Free promotion — claim verification.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ffffff",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable} ${arabic.variable}`}>
      <body className="min-h-dvh">{children}</body>
    </html>
  );
}
