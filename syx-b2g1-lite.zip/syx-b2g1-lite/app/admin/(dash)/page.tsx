import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/lib/db";
import { claimInclude, claimWhere, type ClaimFilters } from "@/lib/claims-query";
import { fmtDateTime, startOfDubaiDay } from "@/lib/format";
import { cleanCode } from "@/lib/validate";
import { setRedeemed } from "../actions";

export const metadata: Metadata = { title: "Claims" };

const PAGE = 50;

// Head office: type the 6-character code the cashier reports, see
// what the buyer typed, tick Redeemed. The same table doubles as the full CRM list.
export default async function ClaimsPage({ searchParams }: { searchParams: Promise<ClaimFilters & { page?: string; code?: string }> }) {
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const code = sp.code ? cleanCode(sp.code) : "";
  const where = code ? { code } : claimWhere(sp);
  const today = startOfDubaiDay();
  const [total, claims, all, redeemed, todayCount] = await Promise.all([
    db.claim.count({ where }),
    db.claim.findMany({ where, include: claimInclude, orderBy: { createdAt: "desc" }, skip: (page - 1) * PAGE, take: PAGE }),
    db.claim.count(),
    db.claim.count({ where: { redeemedAt: { not: null } } }),
    db.claim.count({ where: { createdAt: { gte: today } } }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PAGE));
  const qs = (over: Record<string, string | number>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...sp, ...over })) if (v !== undefined && v !== "" && v !== null) p.set(k, String(v));
    return `?${p}`;
  };
  const hit = code ? claims[0] : undefined;

  return (
    <>
      {/* Verify a code — the head-office job during the soft launch */}
      <section className="card p-5 md:p-6">
        <form method="get" className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1">
            <label htmlFor="code" className="label">Verify a buyer&apos;s code</label>
            <input
              id="code"
              name="code"
              defaultValue={code}
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              maxLength={6}
              placeholder="e.g. PRPGRB"
              className="input num text-2xl font-bold tracking-[0.3em] uppercase"
            />
          </div>
          <button type="submit" className="btn-sm h-14 sm:w-40">Check</button>
        </form>
        {code && (
          <p role="status" className={`mt-4 rounded-xl px-4 py-3 text-base font-semibold text-white ${!hit ? "bg-bad" : hit.redeemedAt ? "bg-bad" : "bg-ok"}`}>
            {!hit
              ? `${code}: not found. Check the code with the customer.`
              : hit.redeemedAt
                ? `${code}: ALREADY REDEEMED on ${fmtDateTime(hit.redeemedAt)} by ${hit.redeemedBy?.username ?? "?"}. Do not give another item.`
                : `${code}: valid, not yet redeemed. ${hit.name} · ${hit.phone} · ${hit.storeName}. Tick "Mark redeemed" below.`}
          </p>
        )}
      </section>

      <dl className="mt-6 grid grid-cols-3 gap-px overflow-hidden rounded-2xl border border-line bg-line">
        {[
          ["Claims", all],
          ["Redeemed", redeemed],
          ["Claims today", todayCount],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper p-4">
            <dt className="text-xs font-semibold tracking-wide text-mute uppercase">{label}</dt>
            <dd className="num mt-1 text-2xl font-bold">{value}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">All claims</h1>
          <p className="mt-1 text-sm text-mute">
            <span className="num">{total}</span> matching. Everything the buyer typed and the code they were given.
          </p>
        </div>
        <a href={`/api/admin/claims.csv${qs({ page: "", code: "" })}`} className="btn-sm" download>
          Export CSV
        </a>
      </div>

      <form method="get" className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-6">
        <div className="col-span-2 md:col-span-3">
          <label htmlFor="q" className="label">Search</label>
          <input id="q" name="q" defaultValue={sp.q ?? ""} placeholder="name, phone, email, store, receipt, code" className="input py-2.5" />
        </div>
        <div>
          <label htmlFor="status" className="label">Status</label>
          <select id="status" name="status" defaultValue={sp.status ?? ""} className="input py-2.5">
            <option value="">All</option>
            <option value="redeemed">Redeemed</option>
            <option value="open">Not redeemed</option>
          </select>
        </div>
        <div>
          <label htmlFor="from" className="label">From</label>
          <input id="from" name="from" type="date" defaultValue={sp.from ?? ""} className="input py-2.5" />
        </div>
        <div>
          <label htmlFor="to" className="label">To</label>
          <input id="to" name="to" type="date" defaultValue={sp.to ?? ""} className="input py-2.5" />
        </div>
        <div className="col-span-2 flex gap-2 md:col-span-6">
          <button type="submit" className="btn-sm">Filter</button>
          <Link href="/admin" className="btn-ghost">Clear</Link>
        </div>
      </form>

      <div className="card mt-6 overflow-x-auto">
        <table className="w-full min-w-[980px]">
          <thead className="border-b border-line">
            <tr>
              <th className="th">Customer</th>
              <th className="th">Phone</th>
              <th className="th">Email</th>
              <th className="th">Store (typed)</th>
              <th className="th">Receipt</th>
              <th className="th">Claimed</th>
              <th className="th">Code</th>
              <th className="th">Redeemed</th>
              <th className="th">Marked</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {claims.map((c) => (
              <tr key={c.id}>
                <td className="td font-medium">{c.name}</td>
                <td className="td num">{c.phone}</td>
                <td className="td text-mute">{c.email}</td>
                <td className="td">{c.storeName}</td>
                <td className="td num">{c.receiptNo ?? <span className="text-mute">none</span>}</td>
                <td className="td num text-mute">{fmtDateTime(c.createdAt)}</td>
                <td className="td num font-semibold tracking-wider">{c.code}</td>
                <td className="td">
                  <form action={setRedeemed.bind(null, c.id, !c.redeemedAt)} className="flex items-center gap-2">
                    {c.redeemedAt ? <span className="pill-ok">YES</span> : <span className="pill-mute">NO</span>}
                    <button type="submit" className="btn-ghost min-h-0 px-2.5 py-1 text-xs">{c.redeemedAt ? "Undo" : "Mark redeemed"}</button>
                  </form>
                </td>
                <td className="td text-mute">
                  {c.redeemedAt ? (
                    <>
                      <span className="num text-ink">{fmtDateTime(c.redeemedAt)}</span>
                      <br />
                      by {c.redeemedBy?.username ?? "?"}
                    </>
                  ) : (
                    ""
                  )}
                </td>
              </tr>
            ))}
            {claims.length === 0 && (
              <tr>
                <td className="td py-10 text-center text-mute" colSpan={9}>No claims match.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {pages > 1 && (
        <nav aria-label="Pages" className="mt-4 flex items-center justify-between text-sm">
          <Link href={qs({ page: page - 1 })} aria-disabled={page <= 1} className={`btn-ghost ${page <= 1 ? "pointer-events-none opacity-40" : ""}`}>Previous</Link>
          <span className="num text-mute">Page {page} of {pages}</span>
          <Link href={qs({ page: page + 1 })} aria-disabled={page >= pages} className={`btn-ghost ${page >= pages ? "pointer-events-none opacity-40" : ""}`}>Next</Link>
        </nav>
      )}
    </>
  );
}
