# SYX — Buy 2 Get 1 Free verification (soft launch)

Buyer verification + a head-office check page for SYX's "Buy 2 Get 1 Free" activation in
the UAE. One QR for every store. Customers open `/claim`, type where they bought (free
text), their name, UAE mobile, email and an optional receipt number, verify the email with a
6-digit OTP and get a one-time 6-character code. One claim per mobile number. The cashier
reports the code to head office; head office types it into `/admin`, sees exactly what the
buyer typed, and ticks it redeemed. No store master data, no per-store links, no cashier app.

| Area | URL | Who |
|---|---|---|
| Customer claim page | `/claim` (single QR) | Public, mobile-first, EN + AR |
| Head office | `/admin` | Admin login |

Stack: Next.js 16 (App Router, server actions), Prisma 6, SQLite (dev) / PostgreSQL (prod),
Tailwind v4, Geist + IBM Plex Sans Arabic, nodemailer (SMTP) for the OTP email.

## Run locally

Requires Node 22+ and pnpm.

```bash
pnpm install
cp .env.example .env        # defaults are fine for local dev
pnpm setup                  # prisma generate + db push + seed
pnpm dev                    # http://localhost:3031
```

| Role | URL | Username | Password |
|---|---|---|---|
| **Admin (head office)** | http://localhost:3031/admin | `syxadmin` | `SamaMedia@2026` |

Customer page: http://localhost:3031/claim

The seed adds 27 demo claims (some marked redeemed). To use a different login, seed with
`ADMIN_USERNAME=… ADMIN_PASSWORD=… pnpm db:seed` (re-running the seed also resets the password).

Without SMTP settings the app runs in **DEMO MODE**: a black banner appears on the customer
page and the OTP is shown on screen instead of emailed, so the whole flow is testable end to end.

Other scripts: `pnpm test` (validators, code alphabet, promo window), `pnpm lint`,
`pnpm typecheck`, `pnpm db:seed` (refreshes demo claims, keeps the admin).

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | yes | `file:./dev.db` for SQLite; a Postgres URL in production |
| `SESSION_SECRET` | yes | 16+ random chars. Signs session cookies and OTP hashes; rotating it logs everyone out |
| `ADMIN_USERNAME` `ADMIN_PASSWORD` | seed only | Head-office login created/updated by `pnpm db:seed` (defaults `syxadmin` / `SamaMedia@2026`) |
| `APP_URL` | prod | Public base URL used inside the QR code (falls back to the request host) |
| `SMTP_HOST` `SMTP_PORT` `SMTP_USER` `SMTP_PASS` `MAIL_FROM` | no | Any SMTP provider. Missing `SMTP_HOST` or `MAIL_FROM` → DEMO MODE |

### Leaving demo mode (real OTP emails)

Any SMTP account works. Examples:
- **Gmail / Google Workspace:** `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, `SMTP_USER=you@yourdomain.com`,
  `SMTP_PASS=<app password>` (Google account → Security → App passwords), `MAIL_FROM="SYX <you@yourdomain.com>"`.
- **Resend:** `SMTP_HOST=smtp.resend.com`, `SMTP_PORT=465`, `SMTP_USER=resend`, `SMTP_PASS=<API key>`,
  `MAIL_FROM` on a verified domain.
- Amazon SES, Mailgun, Postmark, Office 365: their SMTP host/port/credentials.

Set the variables (locally in `.env`, in production as secrets) and restart. The demo banner
disappears and codes are emailed. Subject/body live in `lib/mail.ts`.

## Deploy to Fly.io

One always-on machine with a 1 GB volume at `/data` for the SQLite database — no Postgres
needed. `fly.toml` and the `Dockerfile` are in the repo; the container applies the schema on
every boot. `scripts/deploy-fly.sh` does everything below in one go (idempotent).

```bash
curl -L https://fly.io/install.sh | sh          # installs flyctl (once)
fly auth login
./scripts/deploy-fly.sh                          # app, volume, secrets, build, deploy, seed admin
```

It imports `SMTP_*` and `MAIL_FROM` from `.env` as Fly secrets if present (values never leave
your machine otherwise); with none it deploys in DEMO MODE and you can add them later:
`fly secrets set -a syx-claims SMTP_HOST=… SMTP_PORT=… SMTP_USER=… SMTP_PASS=… MAIL_FROM=…`.

Then: `https://<app>.fly.dev/admin` (`syxadmin` / `SamaMedia@2026`, or whatever you seeded) and
`https://<app>.fly.dev/claim`. Download the QR from Settings and print it.
Redeploy after changes with `fly deploy`. Backup: `fly ssh sftp get /data/syx.db`.

**Railway / Render / any Docker host:** same `Dockerfile`; mount a persistent disk at `/data`
and set the same env vars as in `fly.toml` `[env]` plus the secrets. If you outgrow one machine
(or go serverless, e.g. Vercel), switch Prisma to Postgres: in `prisma/schema.prisma` change
`provider = "sqlite"` to `"postgresql"`, set `DATABASE_URL`, run `pnpm exec prisma db push`
(or adopt `prisma migrate`). Nothing else in the schema is SQLite-specific. Behind a proxy/CDN
make sure `x-forwarded-for` and `x-forwarded-proto` are passed through (rate limits and the
QR URL rely on them).

## How it works

**Customer (`/claim`)** — form → server action `startClaim` validates every field server-side
(required: store name, name, UAE mobile normalised to `+9715XXXXXXXX`, email; optional: receipt
number), checks the promotion window, then the fraud rules; parks the claim in an `Otp` row with
an HMAC-hashed 6-digit OTP (5-minute expiry, 3 attempts, resend after 60 s) and emails it.
`verifyOtp` promotes the pending row to a `Claim` with a 6-character CSPRNG code from the
alphabet `23456789ABCDEFGHJKMNPQRSTUVWXYZ` (no 0/O/1/I/L). The customer sees the code
full-width with EN + AR instructions.

**Fraud rules (server-side, DB-enforced):** one claim per mobile number and, when a receipt
number is given, one per receipt number for the whole promotion (`@unique` on both — the
constraint, not just the pre-check, is the arbiter); per-IP and per-phone rate limits on claims,
OTP verification, resend and login; OTPs stored as HMAC-SHA256; codes CSPRNG-generated.
Customer-facing responses never reveal anything about a phone number beyond the standard
duplicate-claim message.

**Cashier** — no app. The customer shows the code, the cashier hands over the free pack and
reports the code to head office (by message or call, whatever the team uses).

**Head office (`/admin`)** — a "Verify a buyer's code" box: type the 6 characters → green
"valid, not yet redeemed" with the buyer's name, phone and typed store, or red "ALREADY
REDEEMED on … by …" / "not found". One click **Mark redeemed / Undo** per claim (recorded with
time and admin). Below it the full claims table (search by name/phone/email/store/receipt/code,
status and date filters, CSV export honouring the same filters). Settings: promotion start/end
dates, the claim link + print-ready QR PNG, email delivery status.

**Security** — sessions are HMAC-signed httpOnly cookies (`node:crypto`), re-validated against
the user row on every request (disabling an account is immediate); role checks happen in server
components, server actions and route handlers, never only in the client; passwords are bcrypt;
all queries go through Prisma; CSV cells are quoted and formula-escaped.

## Project layout

```
app/
  claim/                 customer page + ClaimForm (client) + actions.ts (server actions)
  admin/(dash)/          claims (verify box + table), settings (server components + forms)
  admin/actions.ts       mark-redeemed / settings mutations
  admin/login/           admin sign-in
  api/admin/claims.csv   CSV export
  api/admin/qr           QR PNG for /claim
lib/                     db, session, auth-actions, validate, codes, mail, ratelimit, settings, claims-query, format, url
prisma/schema.prisma     data model · prisma/seed.ts
assets/                  syx-logo-black.png / syx-logo-white.png (imported by components/Logo.tsx)
tests/                   node:test checks for validators, code alphabet, promo window
scripts/deploy-fly.sh    one-shot Fly.io deploy
```

Known simplifications (marked `ponytail:` in code): the rate limiter is in-process (move to the
DB/Redis if you run more than one instance).
