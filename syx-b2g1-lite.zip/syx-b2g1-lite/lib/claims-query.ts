import type { Prisma } from "@prisma/client";
import { startOfDubaiDay } from "./format";

// Shared between the admin claims table and the CSV export so both honour the
// same filters.
export type ClaimFilters = { q?: string; status?: string; from?: string; to?: string };

export function claimWhere(f: ClaimFilters): Prisma.ClaimWhereInput {
  const w: Prisma.ClaimWhereInput = {};
  const q = f.q?.trim();
  if (q) {
    // SQLite LIKE is case-insensitive for ASCII; on Postgres add `mode: "insensitive"`.
    w.OR = [{ name: { contains: q } }, { phone: { contains: q.replace(/[\s-]/g, "") } }, { email: { contains: q } }, { storeName: { contains: q } }, { receiptNo: { contains: q.toUpperCase() } }, { code: { contains: q.toUpperCase() } }];
  }
  if (f.status === "redeemed") w.redeemedAt = { not: null };
  if (f.status === "open") w.redeemedAt = null;
  const date = /^\d{4}-\d{2}-\d{2}$/;
  if (f.from && date.test(f.from)) w.createdAt = { ...(w.createdAt as object), gte: startOfDubaiDay(f.from) };
  if (f.to && date.test(f.to)) {
    const end = startOfDubaiDay(f.to);
    end.setDate(end.getDate() + 1);
    w.createdAt = { ...(w.createdAt as object), lt: end };
  }
  return w;
}

export const claimInclude = { redeemedBy: true } satisfies Prisma.ClaimInclude;
