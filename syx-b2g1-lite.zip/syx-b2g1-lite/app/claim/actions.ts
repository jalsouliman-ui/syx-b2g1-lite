"use server";

import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { hmac } from "@/lib/session";
import { clientIp, limited } from "@/lib/ratelimit";
import { getSettings, promoOpen } from "@/lib/settings";
import { newOtp, newRedemptionCode } from "@/lib/codes";
import { DEMO_MODE, sendOtpEmail } from "@/lib/mail";
import { ClaimErrors, maskEmail, validateClaim } from "@/lib/validate";

// Every customer-facing error is a code; the client maps it to EN + AR copy.
export type ErrCode =
  | "RATE" | "INVALID" | "CLOSED" | "DUP_PHONE" | "DUP_RECEIPT"
  | "MAIL_FAIL" | "OTP_NOTFOUND" | "OTP_EXPIRED" | "OTP_WRONG" | "OTP_LOCKED" | "RESEND_WAIT" | "SERVER";

export type StartResult =
  | { ok: true; otpId: string; maskedEmail: string; demoOtp?: string }
  | { ok: false; code: ErrCode; errors?: ClaimErrors };
export type VerifyResult =
  | { ok: true; redemptionCode: string }
  | { ok: false; code: ErrCode; attemptsLeft?: number };
export type ResendResult = { ok: true; demoOtp?: string } | { ok: false; code: ErrCode; wait?: number };

const OTP_TTL_MS = 5 * 60 * 1000;
const OTP_MAX_ATTEMPTS = 3;
const RESEND_AFTER_MS = 60 * 1000;

type Pending = { name: string; email: string; storeName: string; receiptNo: string | null; ip: string };

export async function startClaim(form: FormData): Promise<StartResult> {
  const ip = await clientIp();
  if (limited(`claim:ip:${ip}`, 10, 15 * 60_000)) return { ok: false, code: "RATE" };

  const input = {
    name: String(form.get("name") ?? ""),
    phone: String(form.get("phone") ?? ""),
    email: String(form.get("email") ?? "").toLowerCase(),
    storeName: String(form.get("storeName") ?? ""),
    receiptNo: String(form.get("receiptNo") ?? "").toUpperCase(),
  };
  const receiptNo = input.receiptNo.trim() || null; // optional field
  const { errors, phone } = validateClaim(input);
  if (Object.keys(errors).length || !phone) return { ok: false, code: "INVALID", errors };

  if (limited(`claim:phone:${phone}`, 3, 15 * 60_000)) return { ok: false, code: "RATE" };
  if (!promoOpen(await getSettings())) return { ok: false, code: "CLOSED" };

  // Fraud rules: one claim per phone and (when given) per receipt, promotion-wide.
  if (await db.claim.findUnique({ where: { phone } })) return { ok: false, code: "DUP_PHONE" };
  if (receiptNo && (await db.claim.findUnique({ where: { receiptNo } }))) return { ok: false, code: "DUP_RECEIPT" };

  const otp = newOtp();
  const email = input.email.trim();
  const pending: Pending = { name: input.name.trim(), email, storeName: input.storeName.trim(), receiptNo, ip };
  const row = await db.otp.create({
    data: { phone, hash: hmac(otp), expiresAt: new Date(Date.now() + OTP_TTL_MS), payload: JSON.stringify(pending) },
  });

  try {
    await sendOtpEmail(email, otp);
  } catch (e) {
    console.error("OTP email failed", e);
    return { ok: false, code: "MAIL_FAIL" };
  }
  return { ok: true, otpId: row.id, maskedEmail: maskEmail(email), demoOtp: DEMO_MODE ? otp : undefined };
}

export async function verifyOtp(otpId: string, otpInput: string): Promise<VerifyResult> {
  const ip = await clientIp();
  if (limited(`otp:ip:${ip}`, 30, 15 * 60_000)) return { ok: false, code: "RATE" };

  const row = await db.otp.findUnique({ where: { id: otpId } });
  if (!row) return { ok: false, code: "OTP_NOTFOUND" };
  if (row.expiresAt < new Date()) return { ok: false, code: "OTP_EXPIRED" };
  if (row.attempts >= OTP_MAX_ATTEMPTS) return { ok: false, code: "OTP_LOCKED" };

  const otp = otpInput.replace(/\D/g, "");
  if (otp.length !== 6 || hmac(otp) !== row.hash) {
    const u = await db.otp.update({ where: { id: otpId }, data: { attempts: { increment: 1 } } });
    const left = OTP_MAX_ATTEMPTS - u.attempts;
    return left <= 0 ? { ok: false, code: "OTP_LOCKED" } : { ok: false, code: "OTP_WRONG", attemptsLeft: left };
  }

  const p = JSON.parse(row.payload) as Pending;
  // Unique constraints on phone / receiptNo / code are the final arbiter (race-safe).
  for (let i = 0; i < 5; i++) {
    try {
      const claim = await db.claim.create({ data: { code: newRedemptionCode(), phone: row.phone, ...p } });
      await db.otp.delete({ where: { id: otpId } }).catch(() => {});
      return { ok: true, redemptionCode: claim.code };
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
        const target = String((e.meta as { target?: unknown })?.target ?? "");
        if (target.includes("phone")) return { ok: false, code: "DUP_PHONE" };
        if (target.includes("receiptNo")) return { ok: false, code: "DUP_RECEIPT" };
        continue; // code collision (1 in ~887M) — draw again
      }
      throw e;
    }
  }
  return { ok: false, code: "SERVER" };
}

export async function resendOtp(otpId: string): Promise<ResendResult> {
  const row = await db.otp.findUnique({ where: { id: otpId } });
  if (!row) return { ok: false, code: "OTP_NOTFOUND" };
  const wait = Math.ceil((row.sentAt.getTime() + RESEND_AFTER_MS - Date.now()) / 1000);
  if (wait > 0) return { ok: false, code: "RESEND_WAIT", wait };
  if (limited(`resend:${row.phone}`, 5, 60 * 60_000)) return { ok: false, code: "RATE" };

  const otp = newOtp();
  await db.otp.update({
    where: { id: otpId },
    data: { hash: hmac(otp), attempts: 0, sentAt: new Date(), expiresAt: new Date(Date.now() + OTP_TTL_MS) },
  });
  try {
    await sendOtpEmail((JSON.parse(row.payload) as Pending).email, otp);
  } catch (e) {
    console.error("OTP email failed", e);
    return { ok: false, code: "MAIL_FAIL" };
  }
  return { ok: true, demoOtp: DEMO_MODE ? otp : undefined };
}
