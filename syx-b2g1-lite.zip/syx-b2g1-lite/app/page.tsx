import Link from "next/link";
import { Header } from "@/components/Logo";

// Internal index page. Customers arrive at /claim from the shelf QR.
export default function Home() {
  return (
    <div className="min-h-dvh">
      <Header />
      <main className="mx-auto w-full max-w-2xl px-5 py-12">
        <h1 className="text-3xl font-bold tracking-tight">Buy 2 Get 1 Free · verification</h1>
        <p className="mt-2 text-mute">Customers verify their email and get a one-time code; the cashier passes the code to head office; head office checks it here.</p>
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          <Link href="/claim" className="card block p-5 transition-colors hover:bg-soft">
            <p className="text-lg font-semibold">Customer claim page</p>
            <p className="mt-1 text-sm text-mute num">/claim</p>
          </Link>
          <Link href="/admin" className="card block p-5 transition-colors hover:bg-soft">
            <p className="text-lg font-semibold">Head office</p>
            <p className="mt-1 text-sm text-mute">Verify codes, claims list, CSV, settings.</p>
          </Link>
        </div>
      </main>
    </div>
  );
}
