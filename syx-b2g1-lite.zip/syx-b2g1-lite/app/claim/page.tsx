import type { Metadata } from "next";
import { Header } from "@/components/Logo";
import { getSettings, promoOpen } from "@/lib/settings";
import { DEMO_MODE } from "@/lib/mail";
import { ClaimForm } from "./ClaimForm";

export const metadata: Metadata = { title: "Buy 2 Get 1 Free" };
export const dynamic = "force-dynamic";

// Single public claim page (one QR for every store). The customer types the store name.
export default async function ClaimPage() {
  const settings = await getSettings();
  return (
    <div className="flex min-h-dvh flex-col">
      {DEMO_MODE && (
        <div className="bg-ink px-5 py-2 text-center text-xs font-semibold tracking-wide text-paper uppercase">
          Demo mode · OTP is shown on screen, no email is sent
        </div>
      )}
      <Header />
      {!promoOpen(settings) ? (
        <main className="mx-auto w-full max-w-md px-5 py-16">
          <h1 className="text-3xl font-bold tracking-tight">The Buy 2 Get 1 Free promotion isn&apos;t running right now.</h1>
          <p lang="ar" dir="rtl" className="mt-4 text-2xl font-semibold">عرض «اشترِ 2 واحصل على 1 مجاناً» غير متاح حالياً.</p>
        </main>
      ) : (
        <ClaimForm />
      )}
    </div>
  );
}
