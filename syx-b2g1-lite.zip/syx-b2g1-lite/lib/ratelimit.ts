import { headers } from "next/headers";

// ponytail: in-process sliding window. Fine for one instance; move to the DB
// or Redis if the app is ever scaled horizontally.
const hits = new Map<string, number[]>();

/** Returns true when the caller is over `limit` hits within `windowMs`. */
export function limited(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const arr = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= limit) {
    hits.set(key, arr);
    return true;
  }
  arr.push(now);
  hits.set(key, arr);
  if (hits.size > 50_000) hits.clear(); // memory ceiling
  return false;
}

export async function clientIp(): Promise<string> {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "local").trim();
}
