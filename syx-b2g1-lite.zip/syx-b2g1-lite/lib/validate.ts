// Pure validators — shared by server actions (authoritative) and the client
// form (instant feedback). No I/O in this file.

// UAE mobile: accepts 05XXXXXXXX, 5XXXXXXXX, 9715XXXXXXXX, +9715XXXXXXXX,
// 009715XXXXXXXX (with spaces/dashes anywhere). Returns +9715XXXXXXXX or null.
export function normalizeUaePhone(input: string): string | null {
  const d = input.replace(/\D/g, "");
  const local =
    d.length === 10 && d.startsWith("05") ? d.slice(1)
    : d.length === 9 && d.startsWith("5") ? d
    : d.length === 12 && d.startsWith("9715") ? d.slice(3)
    : d.length === 14 && d.startsWith("009715") ? d.slice(5)
    : null;
  return local && /^5[024568]\d{7}$/.test(local) ? `+971${local}` : null;
}

// j•••e@example.com — shown on the OTP screen.
export const maskEmail = (e: string) => {
  const [u, d] = e.split("@");
  return `${u[0] ?? ""}•••${u.length > 1 ? u[u.length - 1] : ""}@${d ?? ""}`;
};

export const isEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 254;

export const REDEMPTION_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"; // no 0 O 1 I L
export const isRedemptionCode = (c: string) => new RegExp(`^[${REDEMPTION_ALPHABET}]{6}$`).test(c);
export const cleanCode = (c: string) => c.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);

// Required: name, phone, email, storeName. Optional: receiptNo (validated if given).
export type ClaimInput = { name: string; phone: string; email: string; storeName: string; receiptNo: string };
export type ClaimErrors = Partial<Record<keyof ClaimInput, string>>;

export function validateClaim(i: ClaimInput): { errors: ClaimErrors; phone: string | null } {
  const errors: ClaimErrors = {};
  const name = i.name.trim();
  if (name.length < 2 || name.length > 80) errors.name = "Enter your full name.";
  const phone = normalizeUaePhone(i.phone);
  if (!phone) errors.phone = "Enter a valid UAE mobile number, e.g. 05X XXX XXXX.";
  if (!isEmail(i.email.trim())) errors.email = "Enter a valid email address.";
  const s = i.storeName.trim();
  if (s.length < 2 || s.length > 80) errors.storeName = "Enter the store name.";
  const r = i.receiptNo.trim();
  if (r && (r.length < 3 || r.length > 40)) errors.receiptNo = "Receipt number should be 3-40 characters.";
  return { errors, phone };
}

