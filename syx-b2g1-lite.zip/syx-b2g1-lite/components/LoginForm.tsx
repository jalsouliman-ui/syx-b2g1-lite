"use client";

import { useActionState } from "react";
import { login, type LoginState } from "@/lib/auth-actions";
import type { Role } from "@/lib/session";

export function LoginForm({ area: role, title, hint }: { area: Role; title: string; hint: string }) {
  const [state, action, pending] = useActionState<LoginState, FormData>(login.bind(null, role), {});
  return (
    <main className="mx-auto w-full max-w-sm px-5 pt-14 pb-16">
      <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
      <p className="mt-2 text-mute">{hint}</p>
      <form action={action} className="mt-8 space-y-5">
        <div>
          <label htmlFor="username" className="label">Username</label>
          <input id="username" name="username" autoComplete="username" autoCapitalize="none" required className="input" />
        </div>
        <div>
          <label htmlFor="password" className="label">Password</label>
          <input id="password" name="password" type="password" autoComplete="current-password" required className="input" />
        </div>
        {state.error && <p role="alert" className="err text-base">{state.error}</p>}
        <button type="submit" disabled={pending} className="btn">{pending ? "Signing in…" : "Sign in"}</button>
      </form>
    </main>
  );
}
