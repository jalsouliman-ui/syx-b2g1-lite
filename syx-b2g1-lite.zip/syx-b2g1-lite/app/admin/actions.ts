"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { saveSettings } from "@/lib/settings";

// All admin mutations: require admin, mutate, redirect back with ?ok= / ?err=.
const back = (path: string, q: Record<string, string>): never => redirect(`${path}?${new URLSearchParams(q)}`);
const str = (f: FormData, k: string) => String(f.get(k) ?? "").trim();

// Head office marks a claim redeemed once the cashier reports the code. Recorded
// with the admin who ticked it.
export async function setRedeemed(id: string, redeemed: boolean) {
  const s = await requireRole("admin");
  await db.claim.update({
    where: { id },
    data: redeemed ? { redeemedAt: new Date(), redeemedById: s.id } : { redeemedAt: null, redeemedById: null },
  });
  revalidatePath("/admin");
}

export async function updateSettings(f: FormData) {
  await requireRole("admin");
  const promoStart = str(f, "promoStart");
  const promoEnd = str(f, "promoEnd");
  const date = /^\d{4}-\d{2}-\d{2}$/;
  if ((promoStart && !date.test(promoStart)) || (promoEnd && !date.test(promoEnd))) back("/admin/settings", { err: "Dates must be YYYY-MM-DD." });
  if (promoStart && promoEnd && promoStart > promoEnd) back("/admin/settings", { err: "Start date is after end date." });
  await saveSettings({ promoStart, promoEnd });
  back("/admin/settings", { ok: "Settings saved." });
}
