import { Header } from "@/components/Logo";
import { AdminNav } from "@/components/AdminNav";
import { logout } from "@/lib/auth-actions";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const s = await requireRole("admin");
  return (
    <div className="min-h-dvh">
      <Header
        href="/admin"
        right={
          <form action={logout.bind(null, "admin")} className="flex items-center gap-4 text-sm">
            <span className="hidden text-mute sm:inline">{s.username}</span>
            <button type="submit" className="font-medium underline underline-offset-4">Sign out</button>
          </form>
        }
      />
      <AdminNav />
      <main className="mx-auto w-full max-w-7xl px-5 py-8 md:px-8">{children}</main>
    </div>
  );
}
