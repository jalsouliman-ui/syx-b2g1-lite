import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Header } from "@/components/Logo";
import { LoginForm } from "@/components/LoginForm";
import { getSession } from "@/lib/session";

export const metadata: Metadata = { title: "Head office sign in" };

export default async function AdminLogin() {
  const s = await getSession();
  if (s?.role === "admin") redirect("/admin");
  return (
    <div className="min-h-dvh">
      <Header />
      <LoginForm area="admin" title="Head office" hint="Verify buyer codes and see what they claimed." />
    </div>
  );
}
