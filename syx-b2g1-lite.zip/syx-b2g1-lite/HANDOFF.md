# SYX Buy 2 Get 1 Free — handoff

## What this is
Soft-launch verification for SYX's "Buy 2 Get 1 Free": a public claim page (`/claim`) where the
buyer types store, name, UAE mobile, email (+ optional receipt no.), verifies the email with a
6-digit OTP and receives a one-time 6-character code; and a head-office page (`/admin`) to
verify that code and tick it redeemed. One claim per mobile number. See README.md for
run/deploy/config details — it is complete.

## State at handoff
- Code: this repo (`main`), tests/lint/types clean. Dev on http://localhost:3031.
- Live: Fly.io app `syx-claims` (region fra, 1 GB volume `syx_data` at /data for SQLite).
  https://syx-claims.fly.dev/claim and https://syx-claims.fly.dev/admin (syxadmin / SamaMedia@2026;
  rotate with `ADMIN_PASSWORD=… pnpm db:seed` on the machine). Redeploy with `scripts/deploy-fly.sh` after `fly auth login`; the Fly account
  belongs to the original owner (transfer the app or create your own with the same script).
- OTP delivery is **email over SMTP** and is currently in **DEMO MODE** (no SMTP secrets set:
  OTP shown on screen). To go live: `fly secrets set -a syx-claims SMTP_HOST=… SMTP_PORT=… SMTP_USER=… SMTP_PASS=… MAIL_FROM=…`
  (any provider; examples in README). The machine restarts and the demo banner disappears.
- Not in scope any more (intentionally removed): receipt photo upload, SMS OTP,
  per-store QR links / store master data, cashier app. A fuller earlier version with those
  exists in the sibling repo `syx-b2g1-source` (checkpoint), not deployed.

## Handy commands
fly logs -a syx-claims · fly status -a syx-claims · fly ssh console -a syx-claims -C "pnpm db:seed"
fly ssh sftp get /data/syx.db (backup)
