// Seed: one admin and ~27 demo claims (typed store names, some redeemed).
// Idempotent: re-running refreshes the demo claims and keeps accounts.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { newRedemptionCode } from "../lib/codes";

const db = new PrismaClient();

// Head-office login. Override at seed time with ADMIN_USERNAME / ADMIN_PASSWORD env vars.
export const ADMIN = { username: process.env.ADMIN_USERNAME ?? "syxadmin", password: process.env.ADMIN_PASSWORD ?? "SamaMedia@2026" };
const RETIRED_USERNAMES = ["admin"]; // old logins removed on every seed
// Store names as customers might type them (free text, no store master data).
const STORES = [
  { name: "Dubai Mall", claims: 10, redeemed: 9 },
  { name: "Marina Mall", claims: 8, redeemed: 6 },
  { name: "Yas Mall, Abu Dhabi", claims: 9, redeemed: 2 },
];

const NAMES = [
  "Fatima Al Mansoori", "Omar Haddad", "Priya Nair", "Ahmed Al Zaabi", "Sara Khoury", "Rohan Menon", "Layla Hassan", "Yusuf Al Ketbi",
  "Mariam Saeed", "Daniel Okafor", "Noor Al Suwaidi", "Karim Nasser", "Aisha Al Shamsi", "Vikram Iyer", "Hana Yoshida", "Tariq Al Balushi",
  "Reem Abdulla", "Joseph Fernandes", "Salma El Sayed", "Bilal Qureshi", "Lina Barakat", "Hamad Al Nuaimi", "Anita D'Souza", "Khalid Rahimi",
  "Maya Antoun", "Faris Al Hammadi", "Ivana Petrova",
];

const DEMO_PHONE_PREFIX = "+97150100"; // +9715010000NN — obviously demo, valid format

async function main() {
  const adminHash = await bcrypt.hash(ADMIN.password, 10);
  const admin = await db.user.upsert({
    where: { username: ADMIN.username },
    create: { username: ADMIN.username, passwordHash: adminHash, role: "admin" },
    update: { passwordHash: adminHash, role: "admin", active: true },
  });
  await db.user.deleteMany({ where: { username: { in: RETIRED_USERNAMES.filter((u) => u !== ADMIN.username) } } });

  // Demo claims are skipped when SEED_DEMO_CLAIMS=0 (production: accounts + stores only).
  if (process.env.SEED_DEMO_CLAIMS === "0") {
    console.log("Seeded admin (demo claims skipped: SEED_DEMO_CLAIMS=0).");
    return;
  }

  // Refresh demo claims only (real claims never use the demo phone prefix).
  await db.claim.deleteMany({ where: { phone: { startsWith: DEMO_PHONE_PREFIX } } });
  await db.otp.deleteMany({ where: { phone: { startsWith: DEMO_PHONE_PREFIX } } });

  let n = 0;
  const now = Date.now();
  for (const s of STORES) {
    for (let i = 0; i < s.claims; i++, n++) {
      const name = NAMES[n % NAMES.length];
      const daysAgo = i === 0 ? 0 : (i * 7) % 6; // a few today, the rest spread over the week
      const createdAt = new Date(now - daysAgo * 86_400_000 - ((i * 37) % 9) * 3_600_000 - 15 * 60_000);
      const receiptNo = `R-${String(4200 + n * 13).padStart(5, "0")}`;
      const redeemed = i < s.redeemed;
      await db.claim.create({
        data: {
          code: newRedemptionCode(),
          name,
          phone: `${DEMO_PHONE_PREFIX}${String(n + 1).padStart(3, "0")}`,
          email: `${name.toLowerCase().replace(/[^a-z ]/g, "").replace(/\s+/g, ".")}@example.com`,
          receiptNo,
          storeName: s.name,
          ip: "127.0.0.1",
          createdAt,
          ...(redeemed
            ? {
                redeemedAt: new Date(createdAt.getTime() + (5 + ((i * 11) % 40)) * 60_000),
                redeemedById: admin.id,
              }
            : {}),
        },
      });
    }
  }

  console.log(`
SYX Buy 2 Get 1 Free — seed complete
------------------------------------
Admin (head office):   http://localhost:3031/admin
  username: ${ADMIN.username}
  password: ${ADMIN.password}

Customer claim page:   http://localhost:3031/claim

Demo claims: ${n}
`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
