import { test } from "node:test";
import assert from "node:assert/strict";
import { cleanCode, isRedemptionCode, maskEmail, normalizeUaePhone, validateClaim } from "../lib/validate";
import { newRedemptionCode } from "../lib/codes";
import { promoOpen } from "../lib/settings";

test("UAE phone normalisation accepts every advertised format", () => {
  for (const raw of ["0501234567", "050 123 4567", "050-123-4567", "501234567", "9715012345 67", "+971501234567", "00971501234567"])
    assert.equal(normalizeUaePhone(raw), "+971501234567", raw);
  for (const bad of ["+447700900123", "041234567", "05012345", "+9715012345678", "0511234567x", ""])
    assert.equal(normalizeUaePhone(bad), null, bad);
  assert.equal(maskEmail("fatima@example.com"), "f•••a@example.com");
});

test("claim validation flags each field", () => {
  const { errors } = validateClaim({ name: "A", phone: "123", email: "nope", storeName: "", receiptNo: "x" });
  assert.deepEqual(Object.keys(errors).sort(), ["email", "name", "phone", "receiptNo", "storeName"]);
  const ok = { name: "Fatima Al Mansoori", phone: "0501234567", email: "f@example.com", storeName: "Marina Mall" };
  assert.deepEqual(validateClaim({ ...ok, receiptNo: "R-1" }).errors, {});
  assert.deepEqual(validateClaim({ ...ok, receiptNo: "" }).errors, {}, "receipt number is optional");
});

test("redemption codes use the unambiguous alphabet only", () => {
  for (let i = 0; i < 500; i++) {
    const c = newRedemptionCode();
    assert.ok(isRedemptionCode(c), c);
    assert.doesNotMatch(c, /[0OI1L]/);
  }
  assert.equal(cleanCode(" ab-cd 12ef "), "ABCD12");
  assert.equal(isRedemptionCode("ABC0EF"), false);
});

test("promotion window is inclusive in UAE time", () => {
  const s = { promoStart: "2026-08-10", promoEnd: "2026-08-20" };
  assert.equal(promoOpen(s, new Date("2026-08-09T21:00:00+04:00")), false);
  assert.equal(promoOpen(s, new Date("2026-08-10T00:30:00+04:00")), true);
  assert.equal(promoOpen(s, new Date("2026-08-20T23:59:00+04:00")), true);
  assert.equal(promoOpen(s, new Date("2026-08-21T00:01:00+04:00")), false);
  assert.equal(promoOpen({ ...s, promoStart: "", promoEnd: "" }), true);
});
