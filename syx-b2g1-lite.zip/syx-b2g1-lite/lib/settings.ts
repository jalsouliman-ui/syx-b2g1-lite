import { db } from "./db";

export type Settings = {
  promoStart: string; // ISO date (YYYY-MM-DD) or ""
  promoEnd: string; // ISO date or ""
};

const DEFAULTS: Settings = { promoStart: "", promoEnd: "" };

export async function getSettings(): Promise<Settings> {
  const rows = await db.setting.findMany();
  const s = { ...DEFAULTS };
  for (const r of rows) {
    if (r.key === "promoStart") s.promoStart = r.value;
    if (r.key === "promoEnd") s.promoEnd = r.value;
  }
  return s;
}

export async function saveSettings(s: Settings) {
  await db.$transaction(
    Object.entries(s).map(([key, v]) =>
      db.setting.upsert({ where: { key }, create: { key, value: String(v) }, update: { value: String(v) } }),
    ),
  );
}

// Claims are blocked outside [promoStart, promoEnd] (inclusive, UAE time).
export function promoOpen(s: Settings, now = new Date()): boolean {
  const today = now.toLocaleDateString("en-CA", { timeZone: "Asia/Dubai" }); // YYYY-MM-DD
  if (s.promoStart && today < s.promoStart) return false;
  if (s.promoEnd && today > s.promoEnd) return false;
  return true;
}
