// Display helpers (UAE time everywhere in the admin/seller UI).
export const TZ = "Asia/Dubai";

export const fmtDateTime = (d: Date | null | undefined) =>
  d ? d.toLocaleString("en-GB", { timeZone: TZ, day: "2-digit", month: "short", year: "2-digit", hour: "2-digit", minute: "2-digit" }) : "";

export const fmtDate = (d: Date | null | undefined) =>
  d ? d.toLocaleDateString("en-GB", { timeZone: TZ, day: "2-digit", month: "short", year: "numeric" }) : "";

export const todayDubai = () => new Date().toLocaleDateString("en-CA", { timeZone: TZ }); // YYYY-MM-DD
export const startOfDubaiDay = (ymd = todayDubai()) => new Date(`${ymd}T00:00:00+04:00`);

export const pct = (num: number, den: number) => (den === 0 ? null : Math.round((num / den) * 1000) / 10);
