import nodemailer from "nodemailer";

// OTP delivery by email over SMTP (works with any provider: Gmail app password,
// SES, Resend, Mailgun, Postmark, Office 365...). Env: SMTP_HOST, SMTP_PORT,
// SMTP_USER, SMTP_PASS, MAIL_FROM. When SMTP_HOST or MAIL_FROM is missing we are
// in DEMO MODE: nothing is sent and the caller shows the OTP on screen.

const host = process.env.SMTP_HOST;
const from = process.env.MAIL_FROM;
export const DEMO_MODE = !(host && from);

const transport = DEMO_MODE
  ? null
  : nodemailer.createTransport({
      host,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: process.env.SMTP_PORT === "465",
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS ?? "" } : undefined,
    });

export async function sendOtpEmail(to: string, otp: string): Promise<void> {
  if (!transport) return; // demo mode: caller surfaces the OTP on screen
  await transport.sendMail({
    from: from!,
    to,
    subject: `${otp} is your SYX verification code`,
    text: `Your SYX verification code is ${otp}. It is valid for 5 minutes.\n\nBuy 2 Get 1 Free — if you did not request this, ignore this email.`,
    html: `<p style="font-family:sans-serif;font-size:16px">Your SYX verification code is</p>
<p style="font-family:monospace;font-size:36px;letter-spacing:.3em;font-weight:700;margin:8px 0">${otp}</p>
<p style="font-family:sans-serif;font-size:14px;color:#666">Valid for 5 minutes. Buy 2 Get 1 Free — if you did not request this, ignore this email.</p>`,
  });
}
