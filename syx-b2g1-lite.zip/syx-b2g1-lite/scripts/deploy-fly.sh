#!/usr/bin/env bash
# One-shot Fly.io deploy for the soft launch (idempotent; re-run to redeploy).
# Prerequisite: `fly auth login` done on this machine. Email vars (SMTP_*, MAIL_FROM), if
# present in .env, are imported as secrets (DATABASE_URL comes from fly.toml).
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$HOME/.fly/bin:$PATH"
APP=$(sed -nE "s/^app = ['"](.*)['"].*/\1/p" fly.toml)
REGION=$(sed -nE "s/^primary_region = ['"]([a-z]+)['"].*/\1/p" fly.toml)

fly apps list 2>/dev/null | awk '{print $1}' | grep -qx "$APP" || fly launch --copy-config --no-deploy --yes --name "$APP" --region "$REGION"
fly volumes list -a "$APP" 2>/dev/null | grep -q syx_data || fly volumes create syx_data -a "$APP" --region "$REGION" --size 1 --yes
fly secrets set -a "$APP" --stage SESSION_SECRET="$(openssl rand -hex 32)" APP_URL="https://$APP.fly.dev" >/dev/null
if grep -qE '^(SMTP_[A-Z_]+|MAIL_FROM)=.' .env 2>/dev/null; then
  grep -E '^(SMTP_[A-Z_]+|MAIL_FROM)=.' .env | sed -E 's/^([A-Z_]+)="?([^"]*)"?$/\1=\2/' | fly secrets import -a "$APP" --stage >/dev/null
  echo "Email (SMTP) secrets staged."
else
  echo "No SMTP_*/MAIL_FROM in .env: deploying in DEMO MODE (OTP shown on screen). Add them later with: fly secrets set -a $APP SMTP_HOST=... SMTP_PORT=... SMTP_USER=... SMTP_PASS=... MAIL_FROM=..."
fi
fly deploy -a "$APP"
fly ssh console -a "$APP" -C "pnpm db:seed" || echo "Seed skipped/failed (run: fly ssh console -a $APP -C 'pnpm db:seed')"
echo
echo "Live:  https://$APP.fly.dev/claim   (customer)"
echo "       https://$APP.fly.dev/admin   (head office: syxadmin / SamaMedia@2026 unless ADMIN_* were set at seed time)"
